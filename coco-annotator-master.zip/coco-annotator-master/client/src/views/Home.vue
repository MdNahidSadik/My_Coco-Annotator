<template>
  <div>
    <div style="padding-top: 55px" />

    <img alt="Vue logo" src="../assets/logo.png" />
    <h1>Web-based Image Annotaiton Tool</h1>
  </div>
</template>

<script>
export default {
  name: "Home"
};
</script>
