# Annotator Web Client

## Project setup

### Development Mode

`docker-compose up --build`

### Production Mode

`docker-compose up -f docker-compose.prod.yml up --build`
