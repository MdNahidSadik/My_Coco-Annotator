# COCO Annotator Backend

## Web Server

## Workers

## Database

## Config
