#!/bin/bash

# Download matterport mask_rcnn_coco model
wget https://github.com/matterport/Mask_RCNN/releases/download/v2.0/mask_rcnn_coco.h5