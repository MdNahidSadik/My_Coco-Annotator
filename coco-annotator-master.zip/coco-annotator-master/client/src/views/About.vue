<template>
  <div>
    <div style="padding-top: 55px" />

    <h1>Web-based Image Annotaiton Tool</h1>
  </div>
</template>

<script>
export default {
  name: "Admin"
};
</script>
